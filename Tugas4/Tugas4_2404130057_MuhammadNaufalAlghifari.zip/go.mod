module github.com/anggyputra/go-class

go 1.26.6

require (
	filippo.io/edwards25519 v1.2.0 // indirect
	github.com/go-sql-driver/mysql v1.10.1 // indirect
	github.com/joho/godotenv v1.5.1 // indirect
)
